-- Table: public.Products

-- DROP TABLE IF EXISTS public."Products";

CREATE TABLE IF NOT EXISTS public."Products"
(
    "Id" text COLLATE pg_catalog."default" NOT NULL,
    "Name" character varying(512) COLLATE pg_catalog."default",
    CONSTRAINT "Products_pkey" PRIMARY KEY ("Id")
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public."Products"
    OWNER to carlornddb;

-- Trigger: products_notify_delete

-- DROP TRIGGER IF EXISTS products_notify_delete ON public."Products";

CREATE TRIGGER products_notify_delete
    AFTER DELETE
    ON public."Products"
    FOR EACH ROW
    EXECUTE FUNCTION public."Products_update_notify"();

-- Trigger: products_notify_insert

-- DROP TRIGGER IF EXISTS products_notify_insert ON public."Products";

CREATE TRIGGER products_notify_insert
    AFTER INSERT
    ON public."Products"
    FOR EACH ROW
    EXECUTE FUNCTION public."Products_update_notify"();

-- Trigger: products_notify_update

-- DROP TRIGGER IF EXISTS products_notify_update ON public."Products";

CREATE TRIGGER products_notify_update
    AFTER UPDATE 
    ON public."Products"
    FOR EACH ROW
    EXECUTE FUNCTION public."Products_update_notify"();