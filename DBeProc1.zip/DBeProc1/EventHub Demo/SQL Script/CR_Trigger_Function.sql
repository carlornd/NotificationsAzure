-- FUNCTION: public.Products_update_notify()

-- DROP FUNCTION IF EXISTS public."Products_update_notify"();

CREATE OR REPLACE FUNCTION public."Products_update_notify"()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$
DECLARE
  Id text;
  Name character varying(512);
BEGIN
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
	Id = NEW."Id";
	Name = NEW."Name";
	PERFORM pg_notify('productsnotification', TG_OP || ';' || Id || ';' || Name || ';' || row_to_json(NEW)::text);
  ELSE
	Id = OLD."Id";
	Name = OLD."Name";
	PERFORM pg_notify('productsnotification', TG_OP || ';' || Id || ';' || Name || ';' || row_to_json(OLD)::text);
  END IF;
  
  RETURN NEW;
END;

$BODY$;

ALTER FUNCTION public."Products_update_notify"()
    OWNER TO carlornddb;
	