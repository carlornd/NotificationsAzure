﻿using System;
using System.Threading.Tasks;
using Azure.Messaging.WebPubSub;
using Azure.Messaging.ServiceBus;
using System.Threading.Tasks;
using System.Diagnostics;

namespace publisher
{
    internal class Program
    {
        // the client that owns the connection and can be used to create senders and receivers
        static ServiceBusClient sbclient;

        // the processor that reads and processes messages from the queue
        static ServiceBusProcessor sbprocessor;

        static WebPubSubServiceClient serviceClient;

        static async Task Main(string[] args)
        {
         

            Console.WriteLine("Hello, World!");

            var connectionString = "Endpoint=https://mypubsubcr.webpubsub.azure.com;AccessKey=+cVTk5RIaAekj6K7An53GKww9/0Q0GWIHaU58GHFOxI=;Version=1.0;";
            var hub = "Hub";
            var message = "test message by CR";

            // Either generate the token or fetch it from server or fetch a temp one from the portal
            serviceClient = new WebPubSubServiceClient(connectionString, hub);
            //await serviceClient.SendToAllAsync(message);

            // =============================
            // Service Bus
            // =============================

            var clientOptions = new ServiceBusClientOptions()
            {
                TransportType = ServiceBusTransportType.AmqpWebSockets
            };
            sbclient = new ServiceBusClient("Endpoint=sb://mycrservicebusns.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=aNnxV5+rN3HiUG2PYpJ7m6rP8jeoCHaXk+ASbBY9i3g=", clientOptions);

            // create a processor that we can use to process the messages
            // TODO: Replace the <QUEUE-NAME> placeholder
            sbprocessor = sbclient.CreateProcessor("myqueue", new ServiceBusProcessorOptions());

            try
            {
                // add handler to process messages
                sbprocessor.ProcessMessageAsync += MessageHandler;

                // add handler to process any errors
                sbprocessor.ProcessErrorAsync += ErrorHandler;

                // start processing 
                await sbprocessor.StartProcessingAsync();

                //Console.WriteLine("Wait for a minute and then press any key to end the processing");
                //Console.ReadKey();

                // stop processing 
                //Console.WriteLine("\nStopping the receiver...");
                //await processor.StopProcessingAsync();
                //Console.WriteLine("Stopped receiving messages");
            }
            finally
            {
                // Calling DisposeAsync on client types is required to ensure that network
                // resources and other unmanaged objects are properly cleaned up.
                //await sbprocessor.DisposeAsync();
                //await sbclient.DisposeAsync();
            }

            // =============================

            Console.WriteLine("'Enter' to terminate the program...");
            Console.ReadLine();

            // stop processing 
            Console.WriteLine("\nStopping the receiver...");
            await sbprocessor.StopProcessingAsync();
            await sbprocessor.DisposeAsync();
            await sbclient.DisposeAsync();
            Console.WriteLine("Stopped receiving messages");

        }

        // handle received messages
        static async Task MessageHandler(ProcessMessageEventArgs args)
        {
            string body = args.Message.Body.ToString();
            Console.WriteLine($"Received: {body}");

            await serviceClient.SendToAllAsync(body);

            // complete the message. message is deleted from the queue. 
            await args.CompleteMessageAsync(args.Message);
        }

        // handle any errors when receiving messages
        static Task ErrorHandler(ProcessErrorEventArgs args)
        {
            Console.WriteLine(args.Exception.ToString());
            return Task.CompletedTask;
        }

    }


}