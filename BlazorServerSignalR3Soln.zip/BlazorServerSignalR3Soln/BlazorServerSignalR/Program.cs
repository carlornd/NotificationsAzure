using BlazorServerSignalR.Data;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.ResponseCompression;
using BlazorServerSignalR.Hubs;
using Azure.Messaging.WebPubSub;
using Azure.Messaging.WebPubSub.Clients;
using Microsoft.Azure.WebPubSub.AspNetCore;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.DependencyInjection;

namespace BlazorServerSignalR
{
	public class Program
	{
		public static void Main(string[] args)
		{
			var builder = WebApplication.CreateBuilder(args);

			// Add services to the container.
			builder.Services.AddRazorPages();
			builder.Services.AddServerSideBlazor();
			builder.Services.AddSingleton<WeatherForecastService>();

			// Add Response Compression Middleware services:
			builder.Services.AddResponseCompression(opts =>
			{
				opts.MimeTypes = ResponseCompressionDefaults.MimeTypes.Concat(
					  new[] { "application/octet-stream" });
			});



			// ClientAccessUrl for the Azure PubSub service:

			// Add Microsoft Azure PubSub Service
			/* 
			var ConnectionString = builder.Configuration.GetSection("PubSubService:ConnectionString").Value;
            builder.Services.AddWebPubSub(
					o => o.ServiceEndpoint = new WebPubSubServiceEndpoint(ConnectionString))
							.AddWebPubSubServiceClient<Sample_ChatApp>();
            */
			/* */
			builder.Services.AddSingleton<Azure.Messaging.WebPubSub.Clients.WebPubSubClient>(sp =>
			{
				//var ClientAccessUrl = builder.Configuration.GetSection("PubSubService:ClientAccessUrl").Value;
				var HubName = builder.Configuration.GetSection("PubSubService:HubName").Value;
				var connectionString = builder.Configuration.GetSection("PubSubService:ConnectionString").Value;

                // See also: 
                // https://learn.microsoft.com/en-us/dotnet/api/overview/azure/messaging.webpubsub.client-readme?view=azure-dotnet-preview
                // and
                // https://learn.microsoft.com/en-us/azure/azure-web-pubsub/quickstarts-push-messages-from-server?tabs=csharp
				// and
                // https://learn.microsoft.com/en-us/azure/azure-web-pubsub/howto-generate-client-access-url?tabs=csharp

                var serviceClient = new Azure.Messaging.WebPubSub.WebPubSubServiceClient(connectionString, HubName);
				var ClientAccessUrl2 = serviceClient.GetClientAccessUri();

                return new Azure.Messaging.WebPubSub.Clients.WebPubSubClient(ClientAccessUrl2);
                //return new Azure.Messaging.WebPubSub.Clients.WebPubSubClient(new Uri(ClientAccessUrl!));
                //new Azure.Messaging.WebPubSub.Clients.WebPubSubClient()
            });
			/* */

			var app = builder.Build();

			// Use Response Compression Middleware at the top of the processing pipeline's configuration:
			app.UseResponseCompression();


			// Configure the HTTP request pipeline.
			if (!app.Environment.IsDevelopment())
			{
				app.UseExceptionHandler("/Error");
				// The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
				app.UseHsts();
			}

			app.UseHttpsRedirection();

			app.UseStaticFiles();

			app.UseRouting();

			app.MapBlazorHub();

			// Between the endpoints for mapping the Blazor hub and the client-side fallback,
			// add an endpoint for the hub immediately after the line app.MapBlazorHub();:
			app.MapHub<ChatHub>("/chathub");


			// Add another SignalR to receive the notification from PubSub
			// Add another SignalR hub to manage the Notification Hub notifications
			
			app.MapHub<MyPubSubNotificationHub>("/mynotificationhub");

			app.MapFallbackToPage("/_Host");

			app.Run();

		}
	}
}