﻿using Microsoft.AspNetCore.SignalR;
using Azure.Messaging.WebPubSub.Clients;

namespace BlazorServerSignalR.Hubs
{
	// Classe derivata da Microsoft.AspNetCore.SignalRHub
	public class MyPubSubNotificationHub : Hub
	{

        private readonly Azure.Messaging.WebPubSub.Clients.WebPubSubClient _MyPubSubNotificationHub;
        IClientProxy myclient;
        public static bool flagalreadydone = false;

        public MyPubSubNotificationHub(WebPubSubClient notificationHubClient)
        {
            _MyPubSubNotificationHub = notificationHubClient;

        }

        /* 
        public async Task SendMessage(string user, string message)
		{
			await Clients.All.SendAsync("ReceiveMessageFromPubSub", user, message);
            
		}
        */

        public async Task Subscribe(string user)
        {
            myclient = Clients.All;

            // await Clients.All.SendAsync("ReceiveMessage", user);

            // Visto che è un singleton, associa la gestione messaggi solo se necessaria (se no è già associata!)

            if (!flagalreadydone)
            {
                _MyPubSubNotificationHub.ServerMessageReceived += async (eventArgs) =>
                {
                    Console.WriteLine($"Receive message: {eventArgs.Message.Data}");
                    System.Diagnostics.Debug.WriteLine($"Receive message: {eventArgs.Message.Data}");

                    // await Clients.All.SendAsync("ReceiveMessageFromPubSub", "user", eventArgs.Message.Data.ToString());
                    await myclient.SendAsync("ReceiveMessageFromPubSub", "user", eventArgs.Message.Data.ToString());

                    // await SendMessage("user", eventArgs.Message.Data.ToString());
                    //return Task.CompletedTask;
                };
                flagalreadydone = true;
            }
            // await _MyPubSubNotificationHub.StartAsync();
            //return Task.CompletedTask;
        }

        public async Task Start()
        {
            await _MyPubSubNotificationHub.StartAsync();
        }


    }
}
