﻿using System;
using System.Threading.Tasks;
using Azure.Messaging.WebPubSub;

namespace publisher
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            var connectionString = "Endpoint=https://mypubsubcr.webpubsub.azure.com;AccessKey=+cVTk5RIaAekj6K7An53GKww9/0Q0GWIHaU58GHFOxI=;Version=1.0;";
            var hub = "Hub";
            var message = "test message by CR";

            // Either generate the token or fetch it from server or fetch a temp one from the portal
            var serviceClient = new WebPubSubServiceClient(connectionString, hub);
            await serviceClient.SendToAllAsync(message);

            Console.WriteLine("Messaggio Inviato!");
        }
    }
}